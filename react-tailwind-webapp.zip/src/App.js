import React from 'react';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="p-8 bg-white rounded-2xl shadow-xl text-center">
        <h1 className="text-2xl font-bold mb-4">Hallo aus deiner React + Tailwind App 🎉</h1>
        <p className="text-gray-600">Diese App ist bereit für dein Webprojekt.</p>
      </div>
    </div>
  );
}

export default App;
